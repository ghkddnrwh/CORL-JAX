from __future__ import annotations

import argparse
import math
import warnings
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import yaml


DEFAULT_LOG_ROOT = Path("logs/wandb_logs_2026_09_22_orl_160")
DEFAULT_OUT_ROOT = Path("paper_diagnostic_tables")

ENV_ORDER = [
    "antmaze-large-navigate-singletask-v0",
    "cube-single-play-singletask-v0",
    "humanoidmaze-medium-navigate-singletask-v0",
    "puzzle-4x4-play-singletask-v0",
    "scene-play-singletask-v0",
]


def display_env(env: str) -> str:
    env_lower = env.lower()

    if "antmaze" in env_lower and "large" in env_lower:
        return "AntMaze Large"
    if "cube" in env_lower:
        return "Cube Single Play"
    if "humanoidmaze" in env_lower and "medium" in env_lower:
        return "HumanoidMaze Medium"
    if "puzzle" in env_lower and "4x4" in env_lower:
        return "Puzzle 4x4"
    if "scene" in env_lower:
        return "Scene Play"

    return env.replace("_", r"\_")


def env_sort_key(env: str) -> Tuple[int, str]:
    try:
        return ENV_ORDER.index(env), env
    except ValueError:
        return len(ENV_ORDER), env


@dataclass(frozen=True)
class RunSpec:
    algo: str
    env: str
    discount: float
    expectile: float
    seed: int
    diag_path: Path
    eval_path: Optional[Path]
    config_path: Path
    delay_period: Optional[int]

    @property
    def setting(self) -> str:
        return "stress" if self.discount >= 0.999 - 1e-12 else "original"

    @property
    def condition(self) -> Tuple[str, float, float]:
        return self.env, self.discount, self.expectile

    @property
    def identity(self) -> Tuple[str, str, float, float, int]:
        return (
            self.algo,
            self.env,
            self.discount,
            self.expectile,
            self.seed,
        )


def _unwrap_wandb_config_value(value):
    if isinstance(value, dict) and "value" in value:
        return value["value"]
    return value


def load_config(path: Path) -> Dict:
    with path.open("r", encoding="utf-8") as f:
        payload = yaml.safe_load(f)

    if payload is None:
        return {}

    return {
        key: _unwrap_wandb_config_value(value)
        for key, value in payload.items()
    }


def _to_float(value, default=np.nan) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _to_int(value, default=-1) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return int(default)


def infer_algo(config: Dict, path: Path) -> str:
    text = " ".join(
        [
            str(config.get("name", "")),
            str(config.get("group", "")),
            str(config.get("project", "")),
            str(config.get("hyperparams_path", "")),
            str(path),
        ]
    ).lower()

    compact = text.replace("-", "").replace("_", "")

    if (
        "ddiql" in compact
        or "decoupleddelayed" in compact
        or "decoupleddelayediql" in compact
    ):
        return "DD-IQL"

    if "iql" in compact:
        return "IQL"

    return "UNKNOWN"


def find_config_upwards(
    start: Path,
    root: Path,
) -> Optional[Path]:
    start = start.resolve()
    root = root.resolve()

    current = start

    for _ in range(8):
        candidate = current / "config.yaml"
        if candidate.exists():
            return candidate

        if current == root:
            break

        if current.parent == current:
            break

        current = current.parent

    return None


def find_eval_path(diag_path: Path, config_path: Path) -> Optional[Path]:
    candidates = [
        diag_path.parent / "eval_logs.npz",
        config_path.parent / "eval_logs.npz",
        diag_path.parent.parent / "eval_logs.npz",
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    return None


def discover_runs(log_root: Path) -> List[RunSpec]:
    log_root = Path(log_root)

    if not log_root.exists():
        raise FileNotFoundError(
            f"Log root does not exist: {log_root}"
        )

    diag_paths = sorted(log_root.rglob("bias_diagnostics.npz"))

    if not diag_paths:
        raise FileNotFoundError(
            "No bias_diagnostics.npz files were found under:\n"
            f"  {log_root}\n\n"
            "Expected each run to contain bias_diagnostics.npz."
        )

    discovered: List[RunSpec] = []

    for diag_path in diag_paths:
        config_path = find_config_upwards(
            diag_path.parent,
            log_root,
        )

        if config_path is None:
            warnings.warn(
                f"Skipping diagnostic without config.yaml: {diag_path}"
            )
            continue

        config = load_config(config_path)

        algo = infer_algo(config, diag_path)

        env = str(config.get("env", "")).strip()
        discount = _to_float(config.get("discount"))
        expectile = _to_float(config.get("iql_tau"))
        seed = _to_int(config.get("seed"))

        delay_period = None
        if config.get("delayed_update_period") is not None:
            delay_period = _to_int(
                config.get("delayed_update_period")
            )

        if algo == "UNKNOWN":
            warnings.warn(
                f"Could not infer algorithm for {diag_path}. Skipping."
            )
            continue

        if not env:
            warnings.warn(
                f"Could not infer environment for {diag_path}. Skipping."
            )
            continue

        if not np.isfinite(discount):
            warnings.warn(
                f"Missing discount for {diag_path}. Skipping."
            )
            continue

        if not np.isfinite(expectile):
            warnings.warn(
                f"Missing iql_tau for {diag_path}. Skipping."
            )
            continue

        if seed < 0:
            warnings.warn(
                f"Missing seed for {diag_path}. Skipping."
            )
            continue

        eval_path = find_eval_path(
            diag_path,
            config_path,
        )

        discovered.append(
            RunSpec(
                algo=algo,
                env=env,
                discount=discount,
                expectile=expectile,
                seed=seed,
                diag_path=diag_path,
                eval_path=eval_path,
                config_path=config_path,
                delay_period=delay_period,
            )
        )

    # Deduplicate exact algorithm/environment/setting/seed combinations.
    # If an exported W&B directory contains duplicate copies, prefer the
    # larger diagnostic file because it is usually the more complete run.
    deduplicated: Dict[
        Tuple[str, str, float, float, int],
        RunSpec,
    ] = {}

    for run in discovered:
        key = run.identity

        if key not in deduplicated:
            deduplicated[key] = run
            continue

        old = deduplicated[key]

        try:
            new_size = run.diag_path.stat().st_size
            old_size = old.diag_path.stat().st_size
        except OSError:
            new_size = old_size = 0

        if new_size > old_size:
            deduplicated[key] = run

    runs = list(deduplicated.values())

    runs.sort(
        key=lambda r: (
            env_sort_key(r.env),
            r.algo,
            r.discount,
            r.expectile,
            r.seed,
        )
    )

    print(
        f"[Layout] Found {len(runs)} unique runs "
        f"from {len(diag_paths)} diagnostic files."
    )

    for algo in ("IQL", "DD-IQL"):
        n = sum(r.algo == algo for r in runs)
        print(f"[Layout] {algo}: {n} runs")

    return runs


@lru_cache(maxsize=None)
def _load_npz_cached(path_str: str) -> pd.DataFrame:
    path = Path(path_str)

    with np.load(path, allow_pickle=True) as data:
        if "timestep" not in data.files:
            raise KeyError(
                f"{path} does not contain 'timestep'."
            )

        timesteps = np.asarray(
            data["timestep"]
        ).reshape(-1)

        frame = pd.DataFrame(
            {"timestep": timesteps}
        )

        n = len(frame)

        for key in data.files:
            if key == "timestep":
                continue

            values = np.asarray(data[key])

            if values.ndim == 1 and len(values) == n:
                frame[key] = values
            elif (
                values.ndim == 2
                and values.shape[0] == n
                and values.shape[1] == 1
            ):
                frame[key] = values[:, 0]

    frame["timestep"] = pd.to_numeric(
        frame["timestep"],
        errors="coerce",
    )

    frame = (
        frame
        .dropna(subset=["timestep"])
        .sort_values("timestep")
        .drop_duplicates(
            subset=["timestep"],
            keep="last",
        )
        .reset_index(drop=True)
    )

    return frame


def load_diag(run: RunSpec) -> pd.DataFrame:
    return _load_npz_cached(
        str(run.diag_path.resolve())
    ).copy()


def load_eval(run: RunSpec) -> pd.DataFrame:
    if run.eval_path is None:
        return pd.DataFrame()

    return _load_npz_cached(
        str(run.eval_path.resolve())
    ).copy()


def window_frame(
    frame: pd.DataFrame,
    start: int,
    end: int,
) -> pd.DataFrame:
    return frame[
        (frame["timestep"] >= start)
        & (frame["timestep"] <= end)
    ].copy()


def seed_metric_mean(
    run: RunSpec,
    metric: str,
    start: int,
    end: int,
    absolute: bool = False,
) -> float:
    frame = window_frame(
        load_diag(run),
        start,
        end,
    )

    if metric not in frame.columns:
        return np.nan

    values = pd.to_numeric(
        frame[metric],
        errors="coerce",
    ).to_numpy(dtype=float)

    if absolute:
        values = np.abs(values)

    values = values[np.isfinite(values)]

    if len(values) == 0:
        return np.nan

    return float(np.mean(values))


def final_eval_seed_value(
    run: RunSpec,
    metric: str,
    last_evals: int = 1,
) -> float:
    frame = load_eval(run)

    if frame.empty or metric not in frame.columns:
        return np.nan

    frame = frame.sort_values("timestep")

    values = pd.to_numeric(
        frame[metric],
        errors="coerce",
    ).to_numpy(dtype=float)

    values = values[np.isfinite(values)]

    if len(values) == 0:
        return np.nan

    if last_evals > 0:
        values = values[-last_evals:]

    return float(np.mean(values))


def summarize_seed_values(
    values: Iterable[float],
) -> Tuple[float, float, int]:
    values = np.asarray(
        list(values),
        dtype=float,
    )

    values = values[np.isfinite(values)]

    if len(values) == 0:
        return np.nan, np.nan, 0

    return (
        float(np.mean(values)),
        float(np.std(values)),
        int(len(values)),
    )


def group_by_condition(
    runs: Sequence[RunSpec],
) -> Dict[
    Tuple[str, float, float],
    List[RunSpec],
]:
    groups: Dict[
        Tuple[str, float, float],
        List[RunSpec],
    ] = {}

    for run in runs:
        groups.setdefault(
            run.condition,
            [],
        ).append(run)

    for key in groups:
        groups[key].sort(
            key=lambda r: r.seed
        )

    return groups


def condition_sort_key(
    condition: Tuple[str, float, float],
):
    env, discount, expectile = condition

    return (
        env_sort_key(env),
        discount,
        expectile,
    )


def is_primary_condition(
    condition: Tuple[str, float, float],
    discount: float,
    expectile: float,
) -> bool:
    _, gamma, tau = condition

    return (
        np.isclose(gamma, discount)
        and np.isclose(tau, expectile)
    )


def format_number(
    value: float,
    digits: int = 3,
) -> str:
    if not np.isfinite(value):
        return r"$\mathrm{nan}$"

    av = abs(value)

    if (
        av >= 1e5
        or (av > 0 and av < 10 ** (-(digits + 1)))
    ):
        exponent = int(
            math.floor(math.log10(av))
        )
        mantissa = value / (10.0 ** exponent)
        return (
            rf"${mantissa:.{digits}f}"
            rf"\times 10^{{{exponent}}}$"
        )

    return rf"${value:.{digits}f}$"


def format_pm(
    mean: float,
    std: float,
    digits: int = 3,
) -> str:
    if not (
        np.isfinite(mean)
        and np.isfinite(std)
    ):
        return r"$\mathrm{nan}$"

    scale = max(abs(mean), abs(std))

    if (
        scale >= 1e5
        or (scale > 0 and scale < 10 ** (-(digits + 1)))
    ):
        def sci(value: float) -> str:
            if value == 0:
                return "0"
            exponent = int(
                math.floor(
                    math.log10(abs(value))
                )
            )
            mantissa = (
                value / (10.0 ** exponent)
            )
            return (
                rf"{mantissa:.{digits}f}"
                rf"\times 10^{{{exponent}}}"
            )

        return (
            rf"${sci(mean)}"
            rf" \pm {sci(std)}$"
        )

    return (
        rf"${mean:.{digits}f}"
        rf" \pm {std:.{digits}f}$"
    )


def format_percent(
    value: float,
    digits: int = 1,
) -> str:
    if not np.isfinite(value):
        return r"$\mathrm{nan}$"

    return rf"${value:.{digits}f}\%$"


def float_label(value: float) -> str:
    return f"{value:g}"


def make_latex_row(
    cells: Sequence[str],
) -> str:
    return " & ".join(cells) + r" \\"


def write_latex_rows(
    path: Path,
    title: str,
    columns: Sequence[str],
    rows: Sequence[str],
    comments: Optional[Sequence[str]] = None,
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    lines = [
        f"% {title}",
        "% Columns: " + " | ".join(columns),
    ]

    if comments:
        lines.extend(
            f"% {comment}"
            for comment in comments
        )

    lines.extend(rows)

    text = "\n".join(lines) + "\n"

    path.write_text(
        text,
        encoding="utf-8",
    )

    print(f"\n[LaTeX rows: {title}]")

    for line in lines:
        print(line)


def write_csv(
    path: Path,
    records: Sequence[Dict],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    pd.DataFrame(
        records
    ).to_csv(
        path,
        index=False,
    )


def common_parser(
    description: str,
) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=description
    )

    parser.add_argument(
        "--log-root",
        type=Path,
        default=DEFAULT_LOG_ROOT,
    )

    parser.add_argument(
        "--out-root",
        type=Path,
        default=DEFAULT_OUT_ROOT,
    )

    parser.add_argument(
        "--early-start",
        type=int,
        default=5_000,
    )

    parser.add_argument(
        "--early-end",
        type=int,
        default=100_000,
    )

    parser.add_argument(
        "--primary-discount",
        type=float,
        default=0.999,
    )

    parser.add_argument(
        "--primary-tau",
        type=float,
        default=0.99,
    )

    parser.add_argument(
        "--last-evals",
        type=int,
        default=1,
        help=(
            "Number of final evaluations to average "
            "inside each seed. Default 1 = final evaluation."
        ),
    )

    return parser