# Anonymous Offline RL Supplementary Code

This archive contains the supplementary JAX implementations used for the paper submission. It is intentionally minimal: experiment outputs, checkpoints, W&B logs, local caches, paper tables, datasets, and git metadata are excluded.

## Included implementations

| Name | Source file | Hyperparameter files |
| --- | --- | --- |
| IQL-JAX | `algorithms/uk_offline/basic/iql_jax.py` | `hyperparams/iql_jax.yml`, `hyperparams/ogbench/iql_jax.yml` |
| DD-IQL-JAX | `algorithms/uk_offline/decoupled_delayed_iql_jax.py` | `hyperparams/decoupled_delayed_iql_jax.yml`, `hyperparams/ogbench/decoupled_delayed_iql_jax.yml` |
| FQL-JAX | `algorithms/uk_offline/basic/fql_jax.py` | `hyperparams/fql_jax.yml`, `hyperparams/ogbench/fql_jax.yml` |
| ReBRAC-JAX, FQL implementation | `algorithms/uk_offline/basic/rebrac_jax_fql_implementation.py` | `hyperparams/rebrac_jax.yml`, `hyperparams/ogbench/rebrac_jax_fql_implementation.yml` |
| DD-ReBRAC-JAX | `algorithms/uk_offline/dd_rebrac_jax.py` | `hyperparams/dd_rebrac_jax.yml`, `hyperparams/ogbench/dd_rebrac_jax.yml` |

The original `algorithms.uk_offline` import namespace is preserved because the implementations import shared checkpointing utilities through that path.

## Example commands

Run from the unpacked archive root. Disable W&B for anonymous/offline runs with `--log_wandb False`.

```bash
python -m algorithms.uk_offline.basic.iql_jax --env antmaze-umaze-v2 --log_wandb False
python -m algorithms.uk_offline.decoupled_delayed_iql_jax --env antmaze-umaze-v2 --log_wandb False
python -m algorithms.uk_offline.basic.fql_jax --env antmaze-large-navigate-singletask-v0 --hyperparams_path hyperparams/ogbench/fql_jax.yml --log_wandb False
python -m algorithms.uk_offline.basic.rebrac_jax_fql_implementation --env antmaze-large-navigate-singletask-v0 --hyperparams_path hyperparams/ogbench/rebrac_jax_fql_implementation.yml --log_wandb False
python -m algorithms.uk_offline.dd_rebrac_jax --env antmaze-large-navigate-singletask-v0 --hyperparams_path hyperparams/ogbench/dd_rebrac_jax.yml --log_wandb False
```

D4RL environments require D4RL/Gym and MuJoCo dependencies. OGBench `*-singletask-*` environments require OGBench and Gymnasium. W&B is optional when `--log_wandb False` is used.
