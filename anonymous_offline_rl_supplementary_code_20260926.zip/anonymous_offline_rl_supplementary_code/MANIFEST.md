# Manifest

Core implementations:

- `algorithms/uk_offline/basic/iql_jax.py`
- `algorithms/uk_offline/decoupled_delayed_iql_jax.py`
- `algorithms/uk_offline/basic/fql_jax.py`
- `algorithms/uk_offline/basic/rebrac_jax_fql_implementation.py`
- `algorithms/uk_offline/dd_rebrac_jax.py`

Shared code:

- `algorithms/uk_offline/common/checkpointing.py`
- package `__init__.py` files needed for imports

Configuration/dependencies:

- `hyperparams/*.yml`
- `hyperparams/ogbench/*.yml`
- `requirements/requirements.txt`
- `requirements_supplement.txt`
- `pyproject.toml`
- `LICENSE`
