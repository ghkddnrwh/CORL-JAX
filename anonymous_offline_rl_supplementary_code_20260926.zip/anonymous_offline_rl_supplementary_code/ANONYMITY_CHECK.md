# Anonymity Check

Checks performed:

- Searched packaged files for local absolute paths, the local username, private-key/token/password strings, and email-like identifiers.
- Excluded `.git`, checkpoints, model weights, datasets, experiment results, paper diagnostic tables, logs, W&B run directories, caches, and bytecode.
- Wrote archive entries with fixed timestamps and package-relative paths to avoid leaking local filesystem metadata.

No author-identifying local paths, usernames, credentials, or email addresses were found by this scan. Generic runtime fields such as `wandb_entity` remain in the code interface but are unset by default.
