"""Reusable training checkpoint and automatic-resume utilities.

This module deliberately knows nothing about IQL, Flax modules, or a concrete
trainer class. The caller supplies serialized trainer state, a state loader, and
an integer timestep getter.
"""

from __future__ import annotations

import copy
import os
import pickle
import random
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

import numpy as np
import yaml

LATEST_CHECKPOINT_NAME = "latest_checkpoint.pkl"
FINAL_CHECKPOINT_NAME = "checkpoint.pkl"
TRAINING_STATUS_NAME = "training_status.yaml"
DEFAULT_CHECKPOINT_VERSION = 4

PathLike = Union[str, Path]


@dataclass(frozen=True)
class WandbResumeState:
    """Persisted W&B identity and the last checkpoint-aligned history step."""

    run_id: Optional[str]
    entity: Optional[str]
    project: Optional[str]
    resume_timestep: Optional[int]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "entity": self.entity,
            "project": self.project,
            "resume_timestep": self.resume_timestep,
        }


def _coerce_optional_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    return int(value)


@dataclass(frozen=True)
class RunPreparation:
    """Result of inspecting and preparing a training output directory."""

    mode: str  # one of: new, resume, completed
    message: str

    @property
    def is_resuming(self) -> bool:
        return self.mode == "resume"

    @property
    def is_completed(self) -> bool:
        return self.mode == "completed"


def _fsync_parent_directory(path: PathLike) -> None:
    """Best-effort durability for a preceding atomic replace on POSIX."""
    directory = Path(path).parent
    flags = getattr(os, "O_DIRECTORY", 0) | os.O_RDONLY
    try:
        directory_fd = os.open(str(directory), flags)
    except OSError:
        return
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _atomic_temporary_path(path: Path) -> Path:
    return path.with_name(f".{path.name}.tmp")


def remove_stale_atomic_temporary_files(
    directory: PathLike,
    target_names: Iterable[str],
) -> None:
    """Remove temporary files left by an uncatchable process termination."""
    directory = Path(directory)
    for target_name in target_names:
        temporary_path = directory / f".{target_name}.tmp"
        if temporary_path.exists():
            temporary_path.unlink()
            _fsync_parent_directory(temporary_path)
            print(f"Removed stale atomic-write temporary file: {temporary_path}")


def save_pickle(path: PathLike, obj: Any) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(obj, f)


def load_pickle(path: PathLike) -> Any:
    with open(path, "rb") as f:
        return pickle.load(f)


def save_pickle_atomic(path: PathLike, obj: Any) -> None:
    """Atomically replace a pickle file without corrupting the previous file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = _atomic_temporary_path(path)
    try:
        with open(temporary_path, "wb") as f:
            pickle.dump(obj, f)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary_path, path)
        _fsync_parent_directory(path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def save_yaml_atomic(path: PathLike, data: Mapping[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = _atomic_temporary_path(path)
    try:
        with open(temporary_path, "w") as f:
            yaml.safe_dump(dict(data), f, sort_keys=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary_path, path)
        _fsync_parent_directory(path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def save_logs_npz(logs: List[Dict[str, Any]], path: PathLike) -> None:
    """Atomically replace an NPZ log file."""
    if not logs:
        return

    keys = logs[0].keys()
    data_to_save: Dict[str, np.ndarray] = {}
    for key in keys:
        values = [log[key] for log in logs]
        try:
            data_to_save[key] = np.asarray(values)
        except ValueError:
            data_to_save[key] = np.asarray(values, dtype=object)

    target_path = Path(path)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = _atomic_temporary_path(target_path)
    try:
        with open(temporary_path, "wb") as f:
            np.savez(f, **data_to_save)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary_path, target_path)
        _fsync_parent_directory(target_path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def evaluation_is_due(timestep: int, eval_freq: int) -> bool:
    return int(timestep) > 0 and int(timestep) % int(eval_freq) == 0


def find_eval_log(
    eval_logs: List[Dict[str, Any]],
    timestep: int,
) -> Optional[Dict[str, Any]]:
    for eval_log in reversed(eval_logs):
        if int(eval_log.get("timestep", -1)) == int(timestep):
            return eval_log
    return None


def upsert_eval_log(
    eval_logs: List[Dict[str, Any]],
    eval_log: Dict[str, Any],
) -> None:
    timestep = int(eval_log["timestep"])
    eval_logs[:] = [
        existing
        for existing in eval_logs
        if int(existing.get("timestep", -1)) != timestep
    ]
    eval_logs.append(dict(eval_log))
    eval_logs.sort(key=lambda item: int(item.get("timestep", -1)))


class TrainingCheckpointManager:
    """Own a single replaceable training checkpoint and its run metadata."""

    def __init__(
        self,
        run_dir: PathLike,
        current_config: Mapping[str, Any],
        default_config: Mapping[str, Any],
        max_timesteps: int,
        identity_ignored_fields: Iterable[str],
        critical_config_fields: Sequence[str],
        checkpoint_type: str,
        checkpoint_version: int = DEFAULT_CHECKPOINT_VERSION,
        accepted_checkpoint_versions: Optional[Iterable[int]] = None,
        legacy_files_to_remove: Iterable[str] = (),
        wandb_enabled: bool = False,
        wandb_entity: Optional[str] = None,
        wandb_project: Optional[str] = None,
    ) -> None:
        self.run_dir = Path(run_dir)
        self.current_config = dict(current_config)
        self.default_config = dict(default_config)
        self.max_timesteps = int(max_timesteps)
        self.identity_ignored_fields = frozenset(identity_ignored_fields)
        self.critical_config_fields = tuple(critical_config_fields)
        self.checkpoint_type = checkpoint_type
        self.checkpoint_version = int(checkpoint_version)
        self.accepted_checkpoint_versions = frozenset(
            accepted_checkpoint_versions
            if accepted_checkpoint_versions is not None
            else (self.checkpoint_version,)
        )
        self.legacy_files_to_remove = tuple(legacy_files_to_remove)
        self.wandb_enabled = bool(wandb_enabled)
        self.wandb_state = WandbResumeState(
            run_id=(uuid.uuid4().hex if self.wandb_enabled else None),
            entity=wandb_entity,
            project=wandb_project,
            resume_timestep=None,
        )
        self.preparation_mode: Optional[str] = None

        self.config_path = self.run_dir / "config.yaml"
        self.status_path = self.run_dir / TRAINING_STATUS_NAME
        self.latest_checkpoint_path = self.run_dir / LATEST_CHECKPOINT_NAME
        self.final_checkpoint_path = self.run_dir / FINAL_CHECKPOINT_NAME
        self.eval_logs_path = self.run_dir / "eval_logs.npz"

        missing_critical = [
            key for key in self.critical_config_fields if key not in self.current_config
        ]
        if missing_critical:
            raise KeyError(
                "Current config is missing checkpoint-critical fields: "
                + ", ".join(missing_critical)
            )

    @property
    def critical_config(self) -> Dict[str, Any]:
        return {
            field: self.current_config[field]
            for field in self.critical_config_fields
        }

    def _normalized_config(self, raw_config: Mapping[str, Any]) -> Dict[str, Any]:
        normalized = dict(self.default_config)
        for key, value in raw_config.items():
            if key not in normalized:
                continue
            if isinstance(value, float) and value.is_integer():
                value = int(value)
            normalized[key] = value
        return normalized

    def _training_identity(self, raw_config: Mapping[str, Any]) -> Dict[str, Any]:
        normalized = self._normalized_config(raw_config)
        return {
            key: normalized[key]
            for key in sorted(normalized)
            if key not in self.identity_ignored_fields
        }

    def _assert_saved_config_matches(self) -> None:
        with open(self.config_path, "r") as f:
            saved_raw = yaml.safe_load(f) or {}
        if not isinstance(saved_raw, dict):
            raise ValueError(f"Invalid saved config file: {self.config_path}")

        saved_identity = self._training_identity(saved_raw)
        current_identity = self._training_identity(self.current_config)
        mismatches = {
            key: (saved_identity.get(key), current_identity.get(key))
            for key in sorted(set(saved_identity) | set(current_identity))
            if saved_identity.get(key) != current_identity.get(key)
        }
        if mismatches:
            mismatch_lines = "\n".join(
                f"  - {key}: saved={saved!r}, current={current!r}"
                for key, (saved, current) in mismatches.items()
            )
            raise ValueError(
                "The checkpoint directory belongs to a different training configuration.\n"
                f"Saved config: {self.config_path}\n"
                f"Mismatched training hyperparameters:\n{mismatch_lines}"
            )

    def _load_status(self) -> Dict[str, Any]:
        if not self.status_path.exists():
            return {}
        with open(self.status_path, "r") as f:
            status = yaml.safe_load(f) or {}
        if not isinstance(status, dict):
            raise ValueError(f"Invalid training status file: {self.status_path}")
        return status

    def _load_wandb_state(self, raw: Any) -> WandbResumeState:
        if not isinstance(raw, Mapping):
            return WandbResumeState(
                run_id=(uuid.uuid4().hex if self.wandb_enabled else None),
                entity=self.wandb_state.entity,
                project=self.wandb_state.project,
                resume_timestep=None,
            )
        raw_run_id = raw.get("run_id")
        if raw_run_id is None:
            return WandbResumeState(
                run_id=(uuid.uuid4().hex if self.wandb_enabled else None),
                entity=raw.get("entity", self.wandb_state.entity),
                project=raw.get("project", self.wandb_state.project),
                resume_timestep=None,
            )
        resume_timestep = _coerce_optional_int(raw.get("resume_timestep"))
        if resume_timestep is not None and resume_timestep < 0:
            raise ValueError("W&B resume_timestep must be non-negative.")
        return WandbResumeState(
            run_id=str(raw_run_id),
            entity=raw.get("entity", self.wandb_state.entity),
            project=raw.get("project", self.wandb_state.project),
            resume_timestep=resume_timestep,
        )

    def _set_wandb_state(self, state: WandbResumeState) -> None:
        self.wandb_state = state

    def mark_wandb_checkpoint_logged(self, timestep: int) -> None:
        """Confirm that W&B history contains a checkpoint marker at ``timestep``."""
        if not self.wandb_enabled or self.wandb_state.run_id is None:
            return
        self._set_wandb_state(
            WandbResumeState(
                run_id=self.wandb_state.run_id,
                entity=self.wandb_state.entity,
                project=self.wandb_state.project,
                resume_timestep=int(timestep),
            )
        )

    def wandb_checkpoint_fields(self) -> Dict[str, Any]:
        """Metrics to merge into the same W&B log call used for a checkpoint step."""
        return {"checkpoint/saved": 1}

    def initialize_wandb(
        self,
        wandb_module: Any,
        config: Mapping[str, Any],
        code_root: PathLike = ".",
    ) -> Any:
        """Create or exactly resume the W&B run associated with this checkpoint.

        New runs use a persisted custom run ID with ``resume='allow'``. Resumed
        local checkpoints use W&B ``resume_from`` at the last checkpoint-aligned
        marker, preventing W&B history from remaining ahead of restored model state.
        Older checkpoints without W&B metadata start a fresh W&B run safely.
        """
        if not self.wandb_enabled:
            return None

        state = self.wandb_state
        if self.preparation_mode == "resume" and state.resume_timestep is None:
            # A run ID without a checkpoint-aligned step cannot be resumed safely:
            # W&B history may be ahead of the restored model. Start a fresh W&B
            # run while preserving the local model continuation.
            state = WandbResumeState(
                run_id=uuid.uuid4().hex,
                entity=state.entity,
                project=state.project,
                resume_timestep=None,
            )
            self._set_wandb_state(state)

        init_kwargs: Dict[str, Any] = {
            "config": dict(config),
            "entity": state.entity,
            "project": state.project or config.get("project"),
            "group": config.get("group"),
            "name": config.get("name"),
        }
        if self.preparation_mode == "resume" and state.resume_timestep is not None:
            init_kwargs["resume_from"] = (
                f"{state.run_id}?_step={int(state.resume_timestep)}"
            )
        else:
            init_kwargs["id"] = state.run_id
            init_kwargs["resume"] = "allow"

        run = wandb_module.init(**init_kwargs)
        actual_run_id = getattr(run, "id", None) or state.run_id
        actual_entity = getattr(run, "entity", None) or state.entity
        actual_project = getattr(run, "project", None) or init_kwargs["project"]
        self._set_wandb_state(
            WandbResumeState(
                run_id=str(actual_run_id),
                entity=actual_entity,
                project=actual_project,
                resume_timestep=state.resume_timestep,
            )
        )
        self._update_status_from_existing_metadata()
        if hasattr(run, "log_code"):
            run.log_code(str(code_root))
        return run

    def initialize_fresh_wandb(
        self,
        wandb_module: Any,
        config: Mapping[str, Any],
        code_root: PathLike = ".",
    ) -> Any:
        """Start a new W&B run after an exact resume attempt fails.

        Local model training continues from the restored checkpoint, but W&B
        history starts in a new run. The new run identity is persisted so later
        checkpoints resume from this replacement run instead of retrying the
        failed historical run.
        """
        if not self.wandb_enabled:
            return None

        state = WandbResumeState(
            run_id=uuid.uuid4().hex,
            entity=self.wandb_state.entity,
            project=self.wandb_state.project or config.get("project"),
            resume_timestep=None,
        )
        self._set_wandb_state(state)

        run = wandb_module.init(
            config=dict(config),
            entity=state.entity,
            project=state.project,
            group=config.get("group"),
            name=config.get("name"),
            id=state.run_id,
            resume="allow",
        )
        actual_run_id = getattr(run, "id", None) or state.run_id
        actual_entity = getattr(run, "entity", None) or state.entity
        actual_project = getattr(run, "project", None) or state.project
        self._set_wandb_state(
            WandbResumeState(
                run_id=str(actual_run_id),
                entity=actual_entity,
                project=actual_project,
                resume_timestep=None,
            )
        )
        self._update_status_from_existing_metadata()
        if hasattr(run, "log_code"):
            run.log_code(str(code_root))
        return run

    def _update_status_from_existing_metadata(self) -> None:
        status = self._load_status()
        status_name = status.get("status", "running")
        timestep = int(status.get("timestep", 0))
        final_checkpoint = status.get("final_checkpoint")
        self._update_status(status_name, timestep, final_checkpoint)

    def _update_status(
        self,
        status: str,
        timestep: int,
        final_checkpoint: Optional[str] = None,
    ) -> None:
        if status not in ("running", "interrupted", "completed"):
            raise ValueError(f"Unknown training status: {status}")
        save_yaml_atomic(
            self.status_path,
            {
                "status": status,
                "timestep": int(timestep),
                "max_timesteps": self.max_timesteps,
                "latest_checkpoint": (
                    LATEST_CHECKPOINT_NAME if status != "completed" else None
                ),
                "final_checkpoint": final_checkpoint,
                "wandb": (
                    self.wandb_state.to_dict()
                    if self.wandb_state.run_id is not None
                    else None
                ),
            },
        )

    def prepare(self) -> RunPreparation:
        """Inspect the run directory and decide new/resume/completed."""
        self.run_dir.mkdir(parents=True, exist_ok=True)
        remove_stale_atomic_temporary_files(
            self.run_dir,
            (
                "config.yaml",
                TRAINING_STATUS_NAME,
                LATEST_CHECKPOINT_NAME,
                FINAL_CHECKPOINT_NAME,
                "eval_logs.npz",
            ),
        )

        directory_is_empty = not any(self.run_dir.iterdir())
        if directory_is_empty:
            save_yaml_atomic(self.config_path, self.current_config)
            self._update_status("running", timestep=0)
            self.preparation_mode = "new"
            return RunPreparation(
                mode="new",
                message="No saved run found. Starting a new training run.",
            )

        if not self.config_path.exists():
            raise FileExistsError(
                "Checkpoint directory is not empty but has no saved config.yaml: "
                f"{self.run_dir}"
            )
        self._assert_saved_config_matches()

        for legacy_name in self.legacy_files_to_remove:
            legacy_path = self.run_dir / legacy_name
            if legacy_path.exists():
                legacy_path.unlink()
                _fsync_parent_directory(legacy_path)
                print(f"Removed obsolete run metadata: {legacy_path}")

        saved_status = self._load_status()
        status_name = saved_status.get("status")
        self._set_wandb_state(self._load_wandb_state(saved_status.get("wandb")))

        if status_name == "completed":
            if self.latest_checkpoint_path.exists():
                self.latest_checkpoint_path.unlink()
                _fsync_parent_directory(self.latest_checkpoint_path)
            self.preparation_mode = "completed"
            return RunPreparation(
                mode="completed",
                message=(
                    "The same training configuration has already completed at "
                    f"{self.run_dir}. Nothing to do."
                ),
            )

        if self.latest_checkpoint_path.exists():
            self.preparation_mode = "resume"
            return RunPreparation(
                mode="resume",
                message=(
                    "Found an incomplete checkpoint with matching hyperparameters. "
                    "Training will continue automatically."
                ),
            )

        if self.final_checkpoint_path.exists():
            self._update_status(
                "completed",
                timestep=self.max_timesteps,
                final_checkpoint=FINAL_CHECKPOINT_NAME,
            )
            self.preparation_mode = "completed"
            return RunPreparation(
                mode="completed",
                message=(
                    "A final checkpoint for the same training configuration already "
                    f"exists at {self.final_checkpoint_path}. Nothing to do."
                ),
            )

        existing_names = {path.name for path in self.run_dir.iterdir()}
        if status_name is None and existing_names == {"config.yaml"}:
            self._update_status("running", timestep=0)
            self.preparation_mode = "new"
            return RunPreparation(
                mode="new",
                message=(
                    "The previous process stopped while creating initial run metadata. "
                    "Restarting safely from timestep 0."
                ),
            )

        if status_name in ("running", "interrupted") and int(
            saved_status.get("timestep", 0)
        ) == 0:
            self.preparation_mode = "new"
            return RunPreparation(
                mode="new",
                message=(
                    "The previous process stopped during initialization before a model "
                    "checkpoint was committed. Restarting safely from timestep 0."
                ),
            )

        status_detail = status_name if status_name is not None else "missing"
        raise RuntimeError(
            "The checkpoint directory contains the same training config, but neither "
            "a completed status nor an in-progress checkpoint exists. Automatic "
            "continuation is impossible without model state. "
            f"status={status_detail!r}, directory={self.run_dir}"
        )

    def _make_payload(
        self,
        timestep: int,
        trainer_state: Any,
        eval_logs: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        return {
            "checkpoint_type": self.checkpoint_type,
            "version": self.checkpoint_version,
            "completed": False,
            "timestep": int(timestep),
            "max_timesteps": self.max_timesteps,
            "critical_config": self.critical_config,
            "trainer_state": trainer_state,
            "eval_logs": copy.deepcopy(eval_logs),
            "numpy_random_state": np.random.get_state(),
            "python_random_state": random.getstate(),
            "wandb": (
                self.wandb_state.to_dict()
                if self.wandb_state.run_id is not None
                else None
            ),
        }

    def save_progress(
        self,
        timestep: int,
        trainer_state: Any,
        eval_logs: List[Dict[str, Any]],
        status: str = "running",
    ) -> None:
        if status not in ("running", "interrupted"):
            raise ValueError("Progress checkpoint status must be running or interrupted.")
        payload = self._make_payload(timestep, trainer_state, eval_logs)
        save_pickle_atomic(self.latest_checkpoint_path, payload)
        self._update_status(status, timestep=timestep)

    def restore(
        self,
        load_trainer_state: Callable[[Any], None],
        get_restored_timestep: Callable[[], int],
    ) -> Tuple[int, List[Dict[str, Any]], int]:
        payload = load_pickle(self.latest_checkpoint_path)
        if (
            not isinstance(payload, dict)
            or payload.get("checkpoint_type") != self.checkpoint_type
        ):
            raise ValueError(
                f"Training checkpoint has an unsupported format: "
                f"{self.latest_checkpoint_path}."
            )

        checkpoint_version = int(payload.get("version", -1))
        if checkpoint_version not in self.accepted_checkpoint_versions:
            expected = ", ".join(
                str(version) for version in sorted(self.accepted_checkpoint_versions)
            )
            raise ValueError(
                f"Unsupported training checkpoint version: {checkpoint_version}. "
                f"Expected one of: {expected}."
            )

        saved_critical_config = payload.get("critical_config", {})
        current_critical_config = self.critical_config
        mismatches = {
            key: (saved_critical_config.get(key), current_value)
            for key, current_value in current_critical_config.items()
            if saved_critical_config.get(key) != current_value
        }
        if mismatches:
            mismatch_lines = "\n".join(
                f"  - {key}: saved={saved!r}, current={current!r}"
                for key, (saved, current) in mismatches.items()
            )
            raise ValueError(
                "Current training configuration is incompatible with the saved "
                f"checkpoint:\n{mismatch_lines}"
            )

        load_trainer_state(payload["trainer_state"])
        restored_timestep = int(get_restored_timestep())
        declared_timestep = int(payload.get("timestep", restored_timestep))
        if restored_timestep != declared_timestep:
            raise ValueError(
                "Training checkpoint timestep metadata does not match trainer state: "
                f"metadata={declared_timestep}, state={restored_timestep}."
            )

        if "numpy_random_state" in payload:
            np.random.set_state(payload["numpy_random_state"])
        if "python_random_state" in payload:
            random.setstate(payload["python_random_state"])

        eval_logs = payload.get("eval_logs", [])
        if not isinstance(eval_logs, list):
            raise ValueError("Training checkpoint eval_logs must be a list.")

        payload_wandb = payload.get("wandb")
        if payload_wandb is not None or self.wandb_enabled:
            self._set_wandb_state(self._load_wandb_state(payload_wandb))
        if (
            self.wandb_state.resume_timestep is not None
            and self.wandb_state.resume_timestep > restored_timestep
        ):
            raise ValueError(
                "W&B resume metadata is ahead of the restored trainer state: "
                f"wandb_step={self.wandb_state.resume_timestep}, "
                f"trainer_step={restored_timestep}."
            )

        self._update_status("running", timestep=restored_timestep)
        return restored_timestep, eval_logs, checkpoint_version

    def complete(
        self,
        timestep: int,
        trainer_state: Any,
        save_final_model: bool,
    ) -> Optional[Path]:
        final_checkpoint: Optional[str] = None
        final_path: Optional[Path] = None
        if save_final_model:
            save_pickle_atomic(self.final_checkpoint_path, trainer_state)
            final_checkpoint = FINAL_CHECKPOINT_NAME
            final_path = self.final_checkpoint_path

        self._update_status(
            "completed",
            timestep=timestep,
            final_checkpoint=final_checkpoint,
        )

        if self.latest_checkpoint_path.exists():
            self.latest_checkpoint_path.unlink()
            _fsync_parent_directory(self.latest_checkpoint_path)
        return final_path


def resolve_checkpoint_path(
    load_model: PathLike,
    run_name: Optional[str] = None,
    seed: Optional[int] = None,
    checkpoint_name: str = FINAL_CHECKPOINT_NAME,
) -> Tuple[Path, Path]:
    """Return ``(run_dir, checkpoint_path)`` for a saved final checkpoint."""
    load_path = Path(load_model)

    if load_path.is_file():
        if load_path.name != checkpoint_name:
            raise FileNotFoundError(
                f"load_model points to a file, but it is not {checkpoint_name}: "
                f"{load_path}"
            )
        return load_path.parent, load_path

    if not load_path.exists():
        raise FileNotFoundError(f"load_model path does not exist: {load_path}")

    candidates: List[Path] = [load_path / checkpoint_name]
    if run_name is not None and seed is not None:
        candidates.append(load_path / run_name / str(seed) / checkpoint_name)
    if run_name is not None:
        run_name_dir = load_path / run_name
        if run_name_dir.exists():
            candidates.extend(sorted(run_name_dir.glob(f"*/{checkpoint_name}")))
    candidates.extend(sorted(load_path.glob(f"*/{checkpoint_name}")))
    candidates.extend(sorted(load_path.glob(f"*/*/{checkpoint_name}")))

    seen = set()
    existing_candidates: List[Path] = []
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        if candidate.exists():
            existing_candidates.append(candidate)

    if not existing_candidates:
        tried = "\n".join(str(path) for path in candidates[:20])
        raise FileNotFoundError(
            f"checkpoint file not found under: {load_path}\n"
            f"Tried candidates:\n{tried}"
        )

    if run_name is not None and seed is not None:
        exact = (load_path / run_name / str(seed) / checkpoint_name).resolve()
        if exact in existing_candidates:
            return exact.parent, exact

    if len(existing_candidates) > 1:
        found = "\n".join(str(path) for path in existing_candidates)
        raise FileNotFoundError(
            f"Multiple {checkpoint_name} files found under {load_path}.\n"
            "Please provide a more specific --load_model path.\n"
            f"Found:\n{found}"
        )

    checkpoint_path = existing_candidates[0]
    return checkpoint_path.parent, checkpoint_path
